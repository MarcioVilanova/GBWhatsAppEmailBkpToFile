/*
**************************************************************************************************
*
*  Project : WhatsAppEmailBackup5
*
*  Purpose : Simple app to grab all the files exported by WhatsApp Backup feature.
*            To be used by Android 5 and above
*
*  Author  : Policia Cientifica do Parana (Marcio Lopes Vilanova e Silva
*
*
*  ***********************************************************************************************
*/

package policiacientifica.gov.pr.br.whatsappemailbackup5;

// Android specific libraries
import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.ContactsContract;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.provider.DocumentFile;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;

// LINGALA libraries for unzipping
import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.io.ZipInputStream;
import net.lingala.zip4j.model.FileHeader;

// Java specific libraries
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

// Main Class
public class MainActivity extends AppCompatActivity {

    /* ***********************************************
        GLOBAL CONSTANTS
       **********************************************  */

    // Constant to identify the Write_External_Storage permission
    private static final int MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE = 1;

    // Constant to identify the Read_Contacts permission
    private static final int MY_PERMISSIONS_REQUEST_READ_CONTACTS = 2;

    // Constant to identify the Permission Intent for directory selection
    private static final int PICK_DIRECTORY_AND_SAVE = 3;

    // Constant to identify the Directory Selection ONLY
    private static final int PICK_DIRECTORY_ONLY = 4;

    // Constant for contacts.txt filename
    private static final String CONTACTS_FILENAME = "contacts.txt";

    // Constant for WhatsApp Clone folder
    private static final String WHATSAPP_CLONE_FOLDER = "/GBWhatsApp/MediaClone";

    // Constant for WhatsApp Original Media folder
    private static final String WHATSAPP_MEDIA_FOLDER = "/GBWhatsApp/Media";

    // Constant for WhatsApp Backup Media Folder
    private static final String WHATSAPP_MEDIA_BACKUP = "/GBWhatsApp/MediaBKP";

    // Constant for Clone Dumb file (indicates when a Cloning process was already done)
    private static final String WHATSAPP_MEDIA_CLONE_DUMB_FILE = "clone.dumb";

    // Constant for CopyMediaFile shared preferences
    private static final String COPY_MEDIA_FILES = "COPY_MEDIA_FILES";

    /* ***********************************************
        GLOBAL VARIABLES
       **********************************************  */

    // List of the attachments URI
    private ArrayList<Uri> gURIList;

    // Output directory to save WhatsApp files
    private DocumentFile gObjDFPickedDir;

    // The name of the Conversation file (only for nem versions of GBWhatsApp)
    private String gStrConversationTextFile;

    // Error flag for media handler (copying GBWhatsApp Media folder with empty files)
    private boolean gBlMediaHandlerError;

    // HashMap of all Media cloned files (if they exist)
    private HashMap gHMMediaKPFiles;

    /*
       ===================================================================
       =
       = Method      : onCreate
       = Description : create the UI
       = Input       : the saved state instance
       = Output      : -
       = OBS         : -
       =
       ===================================================================
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        // Call super method
        super.onCreate(savedInstanceState);

        // Configure UI
        setContentView(R.layout.activity_main);

        // Create the toolbar to hold the "Create report" button
        Toolbar objToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(objToolbar);

        // The "report" button should be floating
        FloatingActionButton objFAB = (FloatingActionButton) findViewById(R.id.fab);

        // Set the button callback routine for creating the report
        objFAB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // call the create report routine
                report_create_auxiliary();
            }
        });  // End of callback routine setting

        // Ask for permission to write on External Storage
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

                // No, for now, there is no need to show any information

            } else {

                // There is no permission, so request it
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE);
            }

        } // End of Persmission to External Storage IF

        // Ask for permission to read Contacts
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.READ_CONTACTS)) {

                // No, for now, there is no need to show any information

            } else {

                // There is no permission, so request it
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_CONTACTS},
                        MY_PERMISSIONS_REQUEST_READ_CONTACTS);
            }
        }  // End of Persmission to read Contacts IF

        // Set initial status
        TextView tvStatus = (TextView) findViewById(R.id.tvStatus);
        tvStatus.append("\n" + getString(R.string.app_started));

        // Check if a output directory was already set (from Preference Data)
        boolean blNoDirSet = false;
        SharedPreferences objSharedPref = this.getPreferences(Context.MODE_PRIVATE);
        String strOutDirNotSet = getString(R.string.output_directory_not_set);
        String strOutDir = objSharedPref.getString(getString(R.string.default_directory),strOutDirNotSet);

        if (strOutDir.equals(strOutDirNotSet)) {

            // No directory was set, so keep this in mind...
            blNoDirSet = true;
        } else {

            // An Output Directory was already, set, so fill the global variable with this
            //gObjDFPickedDir = new DocumentFile()....

        } // End of IF loop to verify the Output Directory set

        tvStatus.append("\n" + getString(R.string.directory_label) + "\n" + strOutDir);

        // Check whether the "Do not copy media files" option was set
        String strCopyMediaFilesTxt = getString(R.string.copy_media_files);
        String strCopyMediaFiles = objSharedPref.getString(COPY_MEDIA_FILES,strCopyMediaFilesTxt);
        tvStatus.append("\n" + strCopyMediaFiles);

        // Verify whether the Media Clone folder already exists
        File objDumbFile = new File(Environment.getExternalStorageDirectory().toString()  + WHATSAPP_MEDIA_FOLDER + "/" + WHATSAPP_MEDIA_CLONE_DUMB_FILE);
        if (objDumbFile.exists())
            tvStatus.append("\n" + getString(R.string.media_clone_done));
        else
            tvStatus.append("\n" + getString(R.string.media_clone_not_done));


        // Fetch the Intent, if there is any available
        Intent objIntent = getIntent();
        String strType = objIntent.getType();
        objIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        // Verify whether an Intent is available
        if (strType != null) {

            // Ok, there is an Intent (probably an Email Sending Intent)
            try {

                // Try to Grab the attachment files list
                gURIList = (ArrayList<Uri>) objIntent.getSerializableExtra(Intent.EXTRA_STREAM);

                // Verify whether is a list or just one file
                if (gURIList == null) {

                    // Ok, it is not a list, so grab the file
                    Uri objUri = (Uri) objIntent.getParcelableExtra(Intent.EXTRA_STREAM);

                    if (objUri == null) {
                        // ERROR! There is no list and no file, a VERY HUGE problem, so , do nothing!!!
                        tvStatus.append("\n" + getString(R.string.error_no_files_to_export) );
                        return;
                    } else {
                        // Ok, there is one single file, create a list out of it!
                        gURIList = new ArrayList<Uri>();
                        gURIList.add(objUri);
                    }

                }

                // debug
                //tvStatus.append("\nIntent type = " + objIntent.getType()+ "\nIntent Action = " + objIntent.getAction()+"\nIntent TEXT = " + objIntent.getStringExtra(Intent.EXTRA_TEXT));

                // Grab the name that the text file will be
                gStrConversationTextFile = objIntent.getStringExtra(Intent.EXTRA_SUBJECT);


            } catch (Exception e) {
                tvStatus.append("\n" + e.getMessage());
                return;
            } // End of try-catch loop for fetching the URI file list

            // Check which Android version is
            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

                // It's 5.0 and above...

                // Não consigo ainda escrever direto no Cartao de Memoria.... então assume que o diretorio nunca está setado
                blNoDirSet = true;

                // First , check whether a output directory was already set (from Preference Data)
                if (blNoDirSet) {

                    // No directory set, so ask for a Directory to save the WhatsApp data
                    Intent intent2 = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    intent2.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

                    // Call this Intent (and process it on onActivityResult routine)
                    startActivityForResult(intent2, PICK_DIRECTORY_AND_SAVE);

                } else  {

                    // Default directory already set, so just Save the Attachment Files
                    saveAllAttachments();

                } // End of IF loop for Default directory not set

            } else {

                // Show it is not yet implemented for older versions
                tvStatus.append("\n" + getString(R.string.older_version_warning));

            } // End of Android version IF

        } // End of IF loop for Intent type


    } // End of onCreate routine

    /* ===================================================================
       =
       = Method      : onRequestPermissionsResult
       = Description : ask for Permissions, if necessary
       = Input       : requestCode    -> the request code
                       permissions[]  -> array of permissions to ask for
                       grantResults[] -> array of permissions granted
       = Output      : -
       = OBS         : do not change it, unless you really know what you're doing...
       =
       ===================================================================
    */
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {

        // Which Permission?
        switch (requestCode) {

            // External storage?
            case MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE: {

                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted

                } else {

                    // permission denied, so, don't do anything at all...
                }
                return;
            }  // End of External Storage permission

            // Read Contacts?
            case MY_PERMISSIONS_REQUEST_READ_CONTACTS: {

                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted

                } else {

                    // permission denied, so, don't do anything at all...
                }
                return;
            }  // End of Read Contacts permission

        } // End of switch request codes

    } // End of onRequestPermissionsResult routine


    /*
       ===================================================================
       =
       = Method      : onCreateOptionsMenu
       = Description : create the menu options
       = Input       : the menu object
       = Output      : true, if it is OK
       = OBS         : -
       =
       ===================================================================
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    } // End of onCreateOptionsMenu

    /*
       ===================================================================
       =
       = Method      : onOptionsItemSelected
       = Description : handle the option selected in menu
       = Input       : the menu item object
       = Output      : true, if it is OK
       = OBS         : -
       =
       ===================================================================
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_directory) {
            selectDirectory();
        }

        if (id == R.id.action_close) {
            closeApp();
        }

        if (id == R.id.action_report) {
            report_create_auxiliary();
        }

        if (id == R.id.action_media_clone_start) {
            media_directory_handler();
        }

        if (id == R.id.action_media_clone_undo) {
            media_directory_undo();
        }

        if (id == R.id.action_media_copy) {
            media_copy_enable_disable();
        }

        return super.onOptionsItemSelected(item);

    } // End of onOptionsItemSelected

    /* ==============================================================================

     * ROUTINE     : selectDirectory
     * DESCRIPTION : to select a Destination Directory
     * INPUT       : -
     * OUTPUT      : -
     * OBS         : -
     *
     ============================================================================== */
    public void selectDirectory() {

        // First, check whether it is Android 5 or above
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

            // Create the intent to fetch only the Directory to save data
            Intent objIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            objIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

            // Call this Intent (and process it on onActivityResult routine)
            startActivityForResult(objIntent, PICK_DIRECTORY_ONLY);

        } else {

            // Older versions, do nothing
            return;

        } // End of IF loop to check Android version

    } // End of selectDirectory

    /* ====================================================================================================
       =
       = Method      : closeApp
       = Description : to hide this app
       = Input       : --
       = Output      : -
       = OBS         : -
       =
    ======================================================================================================  */
    public void closeApp() {

        finish();

    } // End of closeApp routine

    /*
    =======================================================================================================
       =
       = Method      : onActivityResult
       = Description : to handle created Intents on the Main Activity
       = Input       : requestCode -> the code of the request (to identify which Intent called this one)
                       resultCode  -> whether is a result from an Intent
                       resultData  -> the Intent data
       = Output      : -
       = OBS         : -
       =
    ======================================================================================================
    */
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent resultData) {

        // Fetch the textView for debugging purpose
        TextView tvStatus = (TextView) findViewById(R.id.tvStatus);

        // Verify whether something was selected
        if (resultCode == RESULT_OK) {

            // Ok, user selected a Directory to Save the attachments, grab this data
            Uri objTreeUri = resultData.getData();

            // Fetch the directory selected
            gObjDFPickedDir = DocumentFile.fromTreeUri(this, objTreeUri);

            // Store this information in a pair of shared preferences data
            SharedPreferences objSharedPref = getPreferences(Context.MODE_PRIVATE);
            SharedPreferences.Editor objEditor = objSharedPref.edit();
            objEditor.putString(getString(R.string.default_directory),objTreeUri.getPath());
            objEditor.commit();

            // Verify whether is something related to picking a Directory
            if (requestCode == PICK_DIRECTORY_AND_SAVE) {

                // Show this directory in textview
                tvStatus.append("\n" + getString(R.string.output_directory_set) + ":\n  " + objTreeUri.getPath());

                // Fetch the "external" directory (this is where WhatsApp saves its "public" data)
                File objFExtDir = Environment.getExternalStorageDirectory();

                // Verify if it can be read
                if (!objFExtDir.canRead()) {
                    // It can not be read, so this app cannot do anything, tell user and get out
                    tvStatus.append("\n " + getString(R.string.error) + ": " + getString(R.string.cannot_read_directory));
                    return;
                } // End of IF loop for External reading test

                // Save all attachments in the selected directory
                saveAllAttachments();

            } // End of IF loop to handle PICK_DIRECTORY_AND_SAVE request

            // Verify whether is something related to picking a Directory ONLY
            if (requestCode == PICK_DIRECTORY_ONLY) {

                // Show this directory in textview
                tvStatus.append("\n" + getString(R.string.output_directory_set) + ": \n" + objTreeUri.getPath());

            } // End of IF loop to handle PICK_DIRECTORY_ONLY request

        } // End of IF loop to test whether some Intent really called this activity

    } // End of onActivityResult

    /* ======================================================================================================

     * ROUTINE     : retrieveWhatsAppContacts
     * DESCRIPTION : generate a text file with all WhatsApp contacts
     * INPUT       : -
     * OUTPUT      : -
     * OBS         : don't think "external" is the SD Card! It may be or not...
     ======================================================================================================= */
    private void retrieveWhatsAppContacts () {

        // Fetch the Status Textview for debug
        TextView tvStatus = (TextView)findViewById(R.id.tvStatus);

        // First check whether the Output Directory is already set
        if (gObjDFPickedDir == null) {
            // It's null, so grab it

            // Check if a output directory was already set (from Preference Data)
            boolean blNoDirSet = false;
            SharedPreferences objSharedPref = this.getPreferences(Context.MODE_PRIVATE);
            String strOutDirNotSet = getString(R.string.output_directory_not_set);
            String strOutDir = objSharedPref.getString(getResources().getString(R.string.default_directory),strOutDirNotSet);

            if (strOutDir.equals(strOutDirNotSet)) {
                // No directory was set, so keep this in mind...
                blNoDirSet = true;
            }
            tvStatus.append("\n" + getString(R.string.directory_label) + "\n" + strOutDir);

            //strOutDir = strOutDir.replace(":","/");

            tvStatus.append("\nNovo dir = " + strOutDir);

            // Create URI object from this path
            Uri objUri;
            try {
                objUri = Uri.parse(strOutDir);
                tvStatus.append("\nFeito parse da URI");
            } catch (Exception e) {
                tvStatus.append("\nERRO ao montar objeto URI!!!");
                return;
            }

            if (objUri != null) {
                // Fetch the directory selected
                try {
                    tvStatus.append("\nPath da URI criada: " + objUri.getPath());
                    tvStatus.append("\n********************* \n" + objUri.toString());
                    gObjDFPickedDir = DocumentFile.fromTreeUri(this, objUri);
                } catch (Exception e) {
                    tvStatus.append("\nEXception = " + e.toString());
                    return;
                }
            } else {
                tvStatus.append("\nERRO! nao consigo montar objeto do diretorio destino!!!!");
                return;
            }

        } // End of IF loop to test whether global variable for Output directory exists

        // First of all, check whether the accounts file already exists
        if (gObjDFPickedDir.findFile(CONTACTS_FILENAME) != null) {

            // Contacts file already exists, so do nothing! Get out!
            return;
        }

        // Fetch all Raw Contacts from WhatsApp
        Cursor objCursor = getContentResolver().query(
                ContactsContract.RawContacts.CONTENT_URI,
                new String[] { ContactsContract.RawContacts.CONTACT_ID, ContactsContract.RawContacts.DISPLAY_NAME_PRIMARY,
                        ContactsContract.RawContacts.ACCOUNT_NAME, ContactsContract.RawContacts.SYNC1},
                ContactsContract.RawContacts.ACCOUNT_TYPE + " LIKE ?",
                new String[] { "%whatsapp%" },
                ContactsContract.RawContacts.DISPLAY_NAME_PRIMARY + " ASC ");

        // Check whether these contacts already exist
        try {
            if (objCursor.getCount() <= 0) {
                // They do not exist... tell user and get out
                tvStatus.append("\n" + getString(R.string.contacts_not_found));
                objCursor.close();
                return;
            }
        } catch (NullPointerException e) {
            tvStatus.append("\nException 0 = " + e.getMessage());
            objCursor.close();
            return;
        } // End of try-catch loop for verifying WhatsApp contacts

        DocumentFile objDFContacts;

        // Check again whether the accounts file already exists (...we never know...)
        if (gObjDFPickedDir.findFile(CONTACTS_FILENAME) == null) {

            // Contacts file does not exist, so create it
            objDFContacts = gObjDFPickedDir.createFile("text/plain",CONTACTS_FILENAME);
        } else {
            // Contacts file already exists, so do nothing! Get out!
            //tvStatus.append("\nContacts file already exists, OK!");
            objCursor.close();
            return;
        }

        // Define the output stream (to receive the contacts)
        OutputStream objOutS;
        Writer objWriter = null;
        try {
            objOutS = this.getContentResolver().openOutputStream(objDFContacts.getUri());
        } catch (FileNotFoundException e) {
            tvStatus.append("\nException 1 = " + e.getMessage());
            return;
        } // End of try-catch loop for creating a output stream to write the contacts

        // Loop through all contacts
        try {
            int contactNameColumn = objCursor.getColumnIndex(ContactsContract.RawContacts.DISPLAY_NAME_PRIMARY);
            int sync1Column = objCursor.getColumnIndex(ContactsContract.RawContacts.SYNC1);

            while (objCursor.moveToNext()) {

                // Fetch the contact name and number (it's in the SYNC1 column - don't ask me why!)
                String contactsText = objCursor.getString(contactNameColumn) + "=" + objCursor.getString(sync1Column) +  "\n";

                // Store it in contacts file (use UTF-8 encoding)
                objWriter = new OutputStreamWriter(objOutS, "UTF-8");
                objWriter.write(contactsText);
                objWriter.flush();

            } // End of RawContacts loop
        } catch (NullPointerException e) {
            tvStatus.append("\nException 3 = " + e.getMessage());
        } catch (IOException e) {
            tvStatus.append("\nException 4 = " + e.getMessage());
        } // End of try-catch loop for writing the contacts to the file

        // close file
        try {
            objWriter.close();
            objOutS.close();
        } catch (IOException e) {
            tvStatus.append("\nException 5 = " + e.getMessage());
        } // End odf try-catch loop for closing the file

        // close the cursor
        objCursor.close();

    } // End of retrieveWhatsAppContacts

    /* ========================================================================================================

     * ROUTINE     : strGetMimeType
     * DESCRIPTION : to fetch the MIME type of a file using its URI path
     * INPUT       : the extension of the file (must be a String)
     * OUTPUT      : a String depeding which type of MIME
     * OBS         : -
     *
     ========================================================================================================= */
    private String strGetMimeType(String pStrExtension) {

        // If it is a text file...
        if (pStrExtension.equals("txt") || pStrExtension.equals("net") || pStrExtension.equals("us")) {
            return "text/plain";
        }

        // If it is a VCard....
        if (pStrExtension.equals("vcf")) {
            return "text/x-vcard";
        }

        // Everything else will be considered as an octet-stream
        return "application/octet-stream";

    } // End of strGetMimeType

    /* ==================================================================================================

     * ROUTINE     : strRemoveEmojiChars
     * DESCRIPTION : remove emoji chars from a string
     * INPUT       : the string with possible emojis
     * OUTPUT      : the string without emojis
     * OBS         : remove the symbols that cannot be used in filenames: / \
     *
     =================================================================================================== */
    private String strRemoveEmojiChars(String pStrArg) {

        String strResult = "";

        // Loop through all characters, to find out which one is strange (possible emoji)
        for (int i=0; i<pStrArg.length(); i++) {

            // Is it emoji?
            if (pStrArg.codePointAt(i) < 512) {
                strResult = strResult + pStrArg.charAt(i);
            }
        }

        // Substitute the symbols that cannot be used in filenames
        strResult = strResult.replaceAll("[\\\\/:*?\"<>|]", "_");

        return strResult;

    } // End of strRemoveEmojiChars

    /* =======================================================================================================
       =
       = Method      : saveAllAttachments
       = Description : to save all Email Attachment files to a specific directory
       = Input       : -
       = Output      : -
       = OBS         : it's called the WhatsApp Contact Retrieve routine here
       =
       ======================================================================================================  */
    private void saveAllAttachments () {

        boolean blOk = true;

        // Fetch the textView for debugging purpose
        TextView tvStatus = (TextView) findViewById(R.id.tvStatus);

        // Retrieve all WhatsApp contacts and save them in a text file
        retrieveWhatsAppContacts();

        // First check whether we have to copy the Media Files
        SharedPreferences objSharedPref = this.getPreferences(Context.MODE_PRIVATE);
        String strCopyMediaFilesTxt = getString(R.string.copy_media_files);
        String strCopyMediaFiles = objSharedPref.getString(COPY_MEDIA_FILES,strCopyMediaFilesTxt);

        boolean blCopyMediaFiles = false;
        if (strCopyMediaFiles.equals(strCopyMediaFilesTxt)){
            // It is enabled, so disable it
            blCopyMediaFiles = true;
        }

        // loop through all attachments
        int intQtyFiles = 0;
        for (Uri objUri: gURIList) {

            // Fetch this single file
            String strInFilePath = objUri.getPath();

            // debug
            //tvStatus.append("\nExportando arquivo: " + strInFilePath);

            // Verify which type of file based on its extension
            String strExtension = strInFilePath.substring(strInFilePath.lastIndexOf(".")+1,strInFilePath.length());

            //tvStatus.append("\nEXTENSAO = " + strExtension); // debug

            // In newer versions of WhatsApp, the conversation file include a GUID at the end of this filename...
            String strFilenameWithoutExt = "";
            if (strExtension.contains("/")) {

                // There is a GUID separated by a / character, so remove it
                strExtension = strExtension.substring(0,strExtension.indexOf("/"));
                //tvStatus.append("\nNOVA EXTENSAO = " + strExtension);

                strFilenameWithoutExt = strInFilePath.substring(0,strInFilePath.lastIndexOf("."));
                strFilenameWithoutExt = strFilenameWithoutExt.substring(strFilenameWithoutExt.lastIndexOf("/")+1,strFilenameWithoutExt.length());

            } else {

                // There is no GUID, it is a normal file
                strFilenameWithoutExt = strInFilePath.substring(strInFilePath.lastIndexOf("/")+1,strInFilePath.lastIndexOf("."));

            } // End of IF loop to find GUID on filenames


            // First of all, check whether it is a media file...
            if (!(strExtension.equals("us") || strExtension.equals("net") || strExtension.equals("txt") || strExtension.equals("zip") || strExtension.equals("vcf"))) {
                // Ok, it is a media file, so check whether it is necessary to generate it
                if (!blCopyMediaFiles) {
                    // there is no need to copy this media file, so continue to the next iteration of this loop
                    continue;
                }
            } // End of IF loops to check whether this media file should be copied

            //debug
            //tvStatus.append("\nExtensão deste arquivo: " + strExtension + "\nNome do arquivo sem extensão: " + strFilenameWithoutExt);



            // IF a text file, tell user which one is being exported
            if (strExtension.equals("txt")) {

                // Show the contact being exported
                tvStatus.append("\n" + getString(R.string.file_exported) + " " + strFilenameWithoutExt);

            } // End of IF loop for text files exported

            // IF a text file, tell user which one is being exported
            if (strExtension.equals("net") || strExtension.equals("us")) {

                // Show the contact being exported
                tvStatus.append("\n" + getString(R.string.file_exported) + " " + gStrConversationTextFile);

                // Fix the name of the conversation file
                strFilenameWithoutExt = gStrConversationTextFile;

            } // End of IF loop for text files exported


            // Get the file MIME type
            String strMIME = strGetMimeType(strExtension);

            // SOMETIMES, It is necessary to change the directory of these INPUT files, because the WhastApp media files are stored in a
            //  'external' shared memory and WhatsApp sometimes does not know exactly where this 'external' storage is located
            String strInFullPath = "";

            // Fetch the "external" directory (this is where WhatsApp saves its "public" data)
            File objFExternalDir = Environment.getExternalStorageDirectory();

            // debug
            //tvStatus.append("\nExternalStorageDir = " + objFExternalDir.getPath());

            if (!strInFilePath.contains(objFExternalDir.getPath())) {

                // debug
                tvStatus.append("\nÉ preciso mudar o arquivo de input!\nOriginal = " + strInFilePath);

                // It is necessary to change input directory, so fetch only the directory
                String strInExternalDir = strInFilePath.substring(strInFilePath.indexOf("/", 1) + 1, strInFilePath.length());

                // Also, verify whether there is a "WhatsApp" text in the beginning of the text
                if (!(strInExternalDir.startsWith("GBWhatsApp"))) {
                    tvStatus.append("\nNão há o texto 'WhatsApp' no diretório, vamos colocar");
                    strInExternalDir = "GBWhatsApp/" + strInExternalDir;
                    tvStatus.append("\nDEBUG: External Dir inicial 2 = " + strInExternalDir);
                }

                // ... and change it
                strInFullPath = objFExternalDir.getPath().concat("/");
                strInFullPath = strInFullPath.concat(strInExternalDir);

            } else {

                // There is no need to change input directory, keep it
                strInFullPath = strInFilePath;

                // debug
                tvStatus.append("\nNÃO PRECISOU MUDAR O PATH");

            } // End of IF loop to eventually fix the INPUT file paths

            // Now it is time to check whether this single file is a media one that it was cloned to became ZERO length
            if (strExtension.equals("net") || strExtension.equals("us")) {
                // It is the Text Stream of the conversation, do nothing
            } else {
                if (strExtension.equals("txt")) {
                    // It is the old text conversation file, so do nothing as well
                } else {
                    // Ok, it is a media file, check whether is a cloned one (only if CopyMediaFile option is enabled)
                    if (blCopyMediaFiles)
                        strInFullPath = fStrCheckMediaClonedFile(strInFullPath);
                }
            } // End of IF loop to check cloned media files

            // then, verify whether this file is a media one and was already saved earlier (in another run of this app) (again, only if CopyMediaFile option is enabled)
            if (blCopyMediaFiles) {
                if (!(strExtension.equals("us") || strExtension.equals("net") || strExtension.equals("txt") || strExtension.equals("zip"))) {

                    DocumentFile objThisFileAlready = gObjDFPickedDir.findFile(strFilenameWithoutExt + "." + strExtension);

                    // Does it exist?
                    if (objThisFileAlready != null) {
                        // Is it empty?
                        if (objThisFileAlready.length() > 0) {
                            // Ok, this file already exists and it is not empty, so leave it and go to the other file (continue to next iteration of this FOR loop)
                            continue;
                        } else {
                            // Well, the file exists, but it is empty, so it must be deleted , otherwise there will be two different versions of same file
                            objThisFileAlready.delete();
                        } // End of IF loop to LENGTH

                    } // End of IF loop to EXISTS

                } // End of IF loop to verify whether this file is a media that it was already created

            } // End of IF loop to verify MediaCopyFiles option

            // Start the copying process with streams
            InputStream objIS = null;
            OutputStream objOS = null;

            try {
                // Create a reference to the destination file
                DocumentFile objDFNewFile;

                // Remove emoji characters
                strFilenameWithoutExt = strRemoveEmojiChars(strFilenameWithoutExt);

                // Verify which type of file to be created
                if (strMIME.equals("application/octet-stream")) {
                    // These octet-stream files need an extension, because they are too generic
                    objDFNewFile = gObjDFPickedDir.createFile(strMIME, strFilenameWithoutExt + "." + strExtension);
                } else {
                    // Other files, such text files, do not need extension
                    objDFNewFile = gObjDFPickedDir.createFile(strMIME, strFilenameWithoutExt);
                }

                // debug
                //tvStatus.append("\nArquivo de input: " + strInFullPath);

                // Define the output stream (to receive the contents of INPUT file)
                objOS = this.getContentResolver().openOutputStream(objDFNewFile.getUri());

                // Start reading the INPUT file
                if (strExtension.equals("net") || strExtension.equals("us")) {
                    objIS = getContentResolver().openInputStream(objUri);
                } else {
                    objIS = new FileInputStream(strInFullPath);
                }

                // Loop through 1024 bytes chunks in INPUT file
                byte[] buffer = new byte[1024];
                int intRead;
                while ((intRead = objIS.read(buffer)) != -1) {
                    // Write these bytes to the destination file (output stream)
                    objOS.write(buffer, 0, intRead);
                }

                // Close INPUT stream
                objIS.close();

                // write the output file (now the destination file is ready)
                objOS.flush();
                objOS.close();
                intQtyFiles++;

                // Debug which files were already saved
                if (strExtension.equals("us") || strExtension.equals("net"))
                    tvStatus.setText(tvStatus.getText() + "\n " + getString(R.string.file_saved) + gStrConversationTextFile + ".txt");
                else
                    tvStatus.setText(tvStatus.getText() + "\n " + getString(R.string.file_saved) + strFilenameWithoutExt + "." + strExtension);

                // If it is a zipped file, try to unzip it
                if (strExtension.equals("zip")) {

                    tvStatus.append("\n"+ getString(R.string.zip_process_init) + "\n" + getString(R.string.zip_media_bkp_folder));

                    // Create a HashMap with all media cloned files (only necessary if the media files must be copied)
                    gHMMediaKPFiles = new HashMap();
                    File objMediaBKPFiles = new File(Environment.getExternalStorageDirectory() + WHATSAPP_MEDIA_BACKUP);
                    if (blCopyMediaFiles) {
                        ListAllMediaClonedFiles(objMediaBKPFiles);
                    } else {
                        // Do nothing here
                    }

                    // Create the ZIP File object from LINGALA library (3rd party library... hope it works...)
                    ZipFile objZipFile = new ZipFile(strInFullPath);

                    // Create the ZIP input stream from 3rd party library too
                    ZipInputStream objZIS = null;
                    int intCount = 0;

                    // Get the list of file headers from the zip file
                    List objFileHeaderList = objZipFile.getFileHeaders();

                    // Loop through the file headers within this ZIP file
                    for (intCount = 0; intCount < objFileHeaderList.size(); intCount++) {

                        // Fetch the next file to unzip
                        FileHeader objFileHeader = (FileHeader)objFileHeaderList.get(intCount);

                        // Grab its extension
                        String strExtension2 = objFileHeader.getFileName().substring(objFileHeader.getFileName().lastIndexOf(".")+1);

                        // Is it a media file?
                        if (!(strExtension2.equals("us") || strExtension2.equals("net") || strExtension2.equals("txt") || strExtension2.equals("vcf"))) {
                            // Ok, it is a media file, so check whether it is necessary to generate it
                            if (!blCopyMediaFiles) {
                                // there is no need to copy this media file, so continue to the next iteration of this loop
                                continue;
                            }
                        } // End of IF loops to check whether this media file should be copied

                        tvStatus.append("\n" + getString(R.string.unzipping) + " " +  objFileHeader.getFileName() + "...");

                        // Fix the name of this file (removing emojis...)
                        String strThisFileOut = strRemoveEmojiChars(objFileHeader.getFileName());

                        // Now, it is time to verify if this file is a media one and already exists
                        if (!(strExtension2.equals("us") || strExtension2.equals("net") || strExtension2.equals("txt"))) {


                            //tvStatus.append("\nÉ UM ARQUIVO DE MÍDIA, VERIFICAR SE É PARA APAGAR ANTES");
                            // Reference this media file
                            DocumentFile objThisFileAlready = gObjDFPickedDir.findFile(strThisFileOut);

                            // Does it exist?
                            if (objThisFileAlready != null) {

                                //tvStatus.append("\nARQUIVO DE MÍDIA EXISTENTE");
                                // Is it empty?
                                if (objThisFileAlready.length() > 0) {
                                    //tvStatus.append("\nARQUIVO DE MÍDIA NÃO É VAZIO, NÃO PRECISA APAGAR, PASSA PARA A PRÓXIMA MÍDIA");
                                    // Ok, this file already exists and it is not empty, so leave it and go to the other file (continue to next iteration of this FOR loop)
                                    continue;
                                } else {
                                    // Well, the file exists, but it is empty, so it must be deleted , otherwise there will be two different versions of same file
                                    //tvStatus.append("\nARQUIVO DE MÍDIA VAZIO, APAGUE-O");
                                    objThisFileAlready.delete();
                                } // End of IF loop to LENGTH

                            } // End of IF loop to EXISTS

                        } // End of IF loop to verify whether this file is a media that it was already created

                        //tvStatus.append("\nOK, VAMOS CRIAR O ARQUIVO: " + strThisFileOut);

                        // Try to create this single file
                        if (objFileHeader.getFileName().endsWith(".txt")) {
                            objDFNewFile = gObjDFPickedDir.createFile("text/plain", strThisFileOut);
                        } else {
                            if (objFileHeader.getFileName().endsWith(".vcf")) {
                                objDFNewFile = gObjDFPickedDir.createFile("text/x-vcard", strThisFileOut);
                            } else
                                objDFNewFile = gObjDFPickedDir.createFile("application/octet-stream", strThisFileOut);
                        }

                        //tvStatus.append("\nCRIEI O ARQUIVO: " + strThisFileOut);

                        // Create the Output Stream for this unzipped file
                        objOS = this.getContentResolver().openOutputStream(objDFNewFile.getUri());

                        //Get the InputStream from the ZipFile
                        objZIS = objZipFile.getInputStream(objFileHeader);

                        // Loop through all bytes within this specific zip file to copy to the unzipped file
                        int intZipCount;
                        try {
                            while ((intZipCount = objZIS.read(buffer)) != -1) {
                                objOS.write(buffer, 0, intZipCount);
                            }
                        } finally {
                            // Flush and close this specific unzipped file
                            objOS.flush();
                            objOS.close();
                        } // End of try-catch loop for writing to the unzipped file

                        // Verify if this unzipped file is ZERO length
                        if (objDFNewFile.length() == 0) {

                            String strFilename = objDFNewFile.getName();

                            //tvStatus.append("\nARQUIVO ZERADO: " + strFilename);

                            // Find this specific file in the global HashMap of the Backup files
                            String strPathToOriginalFile = fStrFindFileInZIP(strFilename);

                            if (strPathToOriginalFile != "") {
                                // Ok, it was found the original media file, delete this one here
                                objDFNewFile.delete();
                                //tvStatus.append("\nAchei esse: " + strPathToOriginalFile);
                                mWriteTheOriginalUnzippedFile(strFilename,strPathToOriginalFile);
                            } // End of IF loop to Write the Original file

                        } // End of ZERO length file check

                    } // End of FOR loop for each specific file within whole Zip file

                    tvStatus.append("\n" + intCount + " " + getString(R.string.unzippedTotal));

                } // End of IF statement for ZIP files

            } catch (FileNotFoundException e) {
                tvStatus.append("\n" + getString(R.string.file_not_found) + e.getMessage() );
                blOk = false;
            } catch (Exception e) {
                tvStatus.append("\n " + getString(R.string.error) + ": " + e.toString() );
                blOk = false;
            } // End of TRY-catch block for exporting file (and unzipping, if necessary)

        } // End of FOR loop for processing all attachment files

        if (true) return; //debug

        if (blOk) {
            // DEbug how many files were saved
            tvStatus.append("\n" + intQtyFiles + " " + getString(R.string.succesfully_saved));
        }

    } // End of saveAllAttachments

    /* =================================================================================

     * ROUTINE     : report_create_auxiliary
     * DESCRIPTION : create the Intent for selecting the Directory where all conversations
                        text files so it can create a report with all of them
     * INPUT       : -
     * OUTPUT      : -
     * OBS         : -
     *
     ================================================================================== */
    public void report_create_auxiliary() {

        // Fetch the textView for debugging purpose
        TextView tvStatus = (TextView) findViewById(R.id.tvStatus);

        // First, check whether it is Android 5 or above
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

            // Call the Report activity
            Intent objIntent = new Intent(this,ReportActivity.class);
            startActivity(objIntent);

        } else {

            // Older versions, do nothing
            tvStatus.append("\n" + getString(R.string.android5_above));
            return;

        } // End of IF loop to check Android version

    } // End of report_create_auxiliary

    /* =================================================================================

     * ROUTINE     : media_directory_handler
     * DESCRIPTION : handle the process of copying and renaming WhatsApp media folders
     * INPUT       : -
     * OUTPUT      : -
     * OBS         : -
     *
     ================================================================================== */
    public void media_directory_handler() {

        gBlMediaHandlerError = false;

        // Fetch the textView for debugging purpose
        TextView tvStatus = (TextView) findViewById(R.id.tvStatus);

        tvStatus.append("\n" + getString(R.string.media_h_init));

        // WhatsApp original folder
        File objFileOri = new File(Environment.getExternalStorageDirectory().toString()  + WHATSAPP_MEDIA_FOLDER);
        File[] objFilesOri = objFileOri.listFiles();

        if (!objFileOri.exists()) {
            // HUGE problem, the Media folder does not exist! Get out
            tvStatus.append("\n" + getString(R.string.media_folder_missing));
            return;
        }

        // First of all, verify whether this folder is already a clone folder (this cloning process cannot be run several times)
        File objDumbFile = new File(Environment.getExternalStorageDirectory().toString()  + WHATSAPP_MEDIA_FOLDER + "/" + WHATSAPP_MEDIA_CLONE_DUMB_FILE);
        if (objDumbFile.exists()) {
            tvStatus.append("\n" + getString(R.string.media_clone_already_done));
            return;
        }

        //tvStatus.append("\nDiretorio WhatsApp = " + objFileOri.getPath());
        //if (tvStatus.getText() != "") return;

        // WhatsApp clone folder
        File objFileDest = new File(Environment.getExternalStorageDirectory().toString() +  WHATSAPP_CLONE_FOLDER);

        // Create the Clone folder
        if (!objFileDest.exists()) {
            if (!objFileDest.mkdir()) {
                tvStatus.append("\n" + getString(R.string.media_h_mkdir_fail));
                return;
            }
        }

        // Loop through all subfolders and files within this specific folder
        for (int i = 0; i < objFilesOri.length; i++)
        {
            // Create these files and folders recursively
            createFilesRecursive(objFileDest,objFilesOri[i]);
        }

        // Did it work?
        if (gBlMediaHandlerError) {
            // No, it did not work, so tell the user and leave it
            tvStatus.append("\n" + getString(R.string.media_h_final_fail));
            return;
        }

        // Create the Dumb file indicating the cloning process was done
        objDumbFile = new File(Environment.getExternalStorageDirectory().toString()  + WHATSAPP_CLONE_FOLDER + "/" + WHATSAPP_MEDIA_CLONE_DUMB_FILE);
        try {
            objDumbFile.createNewFile();
        } catch (Exception e) {
            tvStatus.append("\n" + getString(R.string.media_h_create_file_fail)+ ": " + e.getMessage());
            return;
        }

        // If this whole process above worked, swap Media folders names (Clone turns to the Original)
        File objMediaBKPFolder = new File(Environment.getExternalStorageDirectory().toString() + WHATSAPP_MEDIA_BACKUP);
        objFileOri = new File(Environment.getExternalStorageDirectory().toString()  + WHATSAPP_MEDIA_FOLDER);

        // Rename orginal Media Folder to Backup
        try {
            if (!objFileOri.renameTo(objMediaBKPFolder)) {
                tvStatus.append("\n" + getString(R.string.media_folder_media_bkp));
                return;
            }
        } catch (Exception e) {
            tvStatus.append("\n" + getString(R.string.media_folder_media_bkp)+ ": " + e.getMessage());
            return;
        }

        // Rename the Clone folder to Media folder
        objFileOri = new File(Environment.getExternalStorageDirectory().toString()  + WHATSAPP_MEDIA_FOLDER);
        objFileDest = new File(Environment.getExternalStorageDirectory().toString() +  WHATSAPP_CLONE_FOLDER);
        try {
            if (!objFileDest.renameTo(objFileOri)) {
                tvStatus.append("\n" + getString(R.string.media_folder_clone_to_media));
                return;
            }
        } catch (Exception e) {
            tvStatus.append("\n" + getString(R.string.media_folder_clone_to_media) + ": " + e.getMessage());
            return;
        }

        // Tell it is over
        tvStatus.append("\n" + getString(R.string.media_h_final_success));


    } // End of media_directory_handler

    /* =================================================================================

     * ROUTINE     : createFilesRecursive
     * DESCRIPTION : recursive method to create files and folders
     * INPUT       : pObjParentFolder -> the parent folder where the file or folder will be created within
     *               pStrThisFile     -> file or folder to be created within the Parent Folder
     * OUTPUT      : -
     * OBS         : -
     *
     ================================================================================== */
    public void createFilesRecursive (File pObjParentFolder, File pObjThisFile) {

        // Fetch the textView for debugging purpose
        TextView tvStatus = (TextView) findViewById(R.id.tvStatus);

        // Verify if this Parent folder exists
        if (!pObjParentFolder.exists()) {
            //tvStatus.append("\nPasta não existe " + pObjParentFolder.getName());
            // It does not exist, so create it
            if (!pObjParentFolder.mkdir()) {
                tvStatus.append("\n" + getString(R.string.error) + getString(R.string.media_h_mkdir_fail) + ": " + pObjParentFolder.getName());
                gBlMediaHandlerError = true;
                return;
            }
            //tvStatus.append("\nPasta " + pObjParentFolder.getName() + " criada com SUCESSO!");
        }

        // Ok, at this point the Parent folder should exist... Try to create the subfile or subfolder...
        // It is just a single file, so create it empty and leave
        File objThisSingleFile = new File(pObjParentFolder.getPath() + "/" + pObjThisFile.getName());
        if (pObjThisFile.isFile()) {
            try {
                if (!objThisSingleFile.exists()) {
                    objThisSingleFile.createNewFile();
                    //tvStatus.append("\nCriado o arquivo ou pasta: " + objThisSingleFile.getName());
                }
            } catch (Exception e) {
                tvStatus.append(getString(R.string.media_h_create_file_fail) + " " + objThisSingleFile.getPath() + " => " + e.toString() );
                gBlMediaHandlerError = true;
                return;
            }
        } else {
            // It is not a single file, but a subfolder, so create it, only if it does not exist...
            if (!objThisSingleFile.exists()) {
                if (!objThisSingleFile.mkdir()) {
                    tvStatus.append("\n " + getString(R.string.media_h_mkdir_fail) + " " + objThisSingleFile.getPath());
                    gBlMediaHandlerError = true;
                    return;
                }
            }

            // It is a subfolder, so list its subfolders
            File[] arrSubFiles = pObjThisFile.listFiles();

            // Create the subfiles or subfolders, recursively
            for (int i = 0; i < arrSubFiles.length; i++)
            {
                createFilesRecursive(objThisSingleFile,arrSubFiles[i]);
            }

        }

    } // End of createFilesRecursive


    /* =================================================================================

     * ROUTINE     : media_directory_undo
     * DESCRIPTION : undo the process of renaming WhatsApp media folders
     * INPUT       : -
     * OUTPUT      : -
     * OBS         : -
     *
     ================================================================================== */
    public void media_directory_undo() {

        // Fetch the textView for debugging purpose
        TextView tvStatus = (TextView) findViewById(R.id.tvStatus);

        tvStatus.append("\n" + getString(R.string.media_undo_init));

        /* It is a two stage process:
           + First  : delete the Media folder that it is a clone of the original one
           + Second : rename the Backup folder to Media Folder
        */

        // Verify whether the Media current folder is a clone one, so check whether the Dumb file exists
        // Create the Dumb file indicating the cloning process was done
        File objDumbFile = new File(Environment.getExternalStorageDirectory().toString()  + WHATSAPP_MEDIA_FOLDER + "/" + WHATSAPP_MEDIA_CLONE_DUMB_FILE);
        if (!objDumbFile.exists()) {
            tvStatus.append("\n" + getString(R.string.media_clone_not_done));
            return;
        }

        // OK, it seems that the current Media folder is a clone one, go on
        File objMediaFolder = new File(Environment.getExternalStorageDirectory().toString()  + WHATSAPP_MEDIA_FOLDER);

        if (!fBlDeleteDir(objMediaFolder)) {
            tvStatus.append("\n" + getString(R.string.media_undo_fail_cannot_delete_clone));
            return;
        }

        // Ok, the Cloned Media folder was deleted, so rename the Backup folder to Media folder
        objMediaFolder = new File(Environment.getExternalStorageDirectory().toString()  + WHATSAPP_MEDIA_FOLDER);
        File objBKPMediaFolder = new File(Environment.getExternalStorageDirectory().toString()  + WHATSAPP_MEDIA_BACKUP);

        try {
            if (!objBKPMediaFolder.renameTo(objMediaFolder))
            {
                tvStatus.append("\n"  + getString(R.string.media_undo_cannot_rename_bkp_to_media));
                return;
            }
        } catch (Exception e) {
            tvStatus.append("\n" + getString(R.string.media_undo_cannot_rename_bkp_to_media) + ": " + e.getMessage());
            return;
        }

        tvStatus.append("\n" + getString(R.string.media_undo_success));

    } // End of media_directory_undo

    /* =================================================================================

     * ROUTINE     : fBlDeleteDir
     * DESCRIPTION : to Delete the directory and its subdirectories as well, recursively
     * INPUT       : the File object of the Directory
     * OUTPUT      : TRUE, if success
     * OBS         : ONLY EMPTY FILES WILL BE DELETED!!! Don't worry!
     *
     ================================================================================== */
    public static boolean fBlDeleteDir(File pObjDir) {

        // Verify whether is a Directory
        if (pObjDir.isDirectory()) {

            // It is a directory, find its children
            String[] arrStrSubFolders = pObjDir.list();

            // Loop through all subfolders
            for (int i=0; i<arrStrSubFolders.length; i++) {

                // Call this method for this subfolder
                boolean blSuccess = fBlDeleteDir(new File(pObjDir, arrStrSubFolders[i]));

                // If it fails, return false
                if (!blSuccess) {
                    return false;
                }

            } // End of FOR loop for all subfolders

            // No this folder should be empty, try to delete it
            return pObjDir.delete();

        } else {

            // It is a single file, make sure it has no bytes
            if (pObjDir.length() == 0) {
                return  pObjDir.delete();
            }
        }

        // If it goes here, return true
        return true;

    } // End of fBlDeleteDir

    /* =================================================================================

     * ROUTINE     : fStrCheckMediaClonedFile
     * DESCRIPTION : find the Original media file (first check whether is a real cloned media file (ZERO length))
     * INPUT       : the file full path string
     * OUTPUT      : the original media file path, if it is not a cloned file, so return the same input string
     * OBS         : -
     *
     ================================================================================== */
    private String fStrCheckMediaClonedFile(String pStrFilePath) {

        // Fetch the textView for debugging purpose
        //TextView tvStatus = (TextView) findViewById(R.id.tvStatus);

        //tvStatus.append("\nSerá arquivo clonado? : " + pStrFilePath);

        // Reference this file in an object
        File objFileOri = new File(pStrFilePath);
        if (objFileOri == null) {
            // If no File object was created, return the original path
            return pStrFilePath;
        }

        // Does this file really exist?
        if (!objFileOri.exists())
            return pStrFilePath;

        // Is it a ZERO length file?
        if (objFileOri.length() > 0) {
            // It is a real file, so return it
            return pStrFilePath;
        }

        // Ok, it is a ZERO length file, try to find it in the Backup Media folder
        String strResult = pStrFilePath.replace(WHATSAPP_MEDIA_FOLDER,WHATSAPP_MEDIA_BACKUP);
        File objFileResult = new File(strResult);

        if (objFileResult.exists()) {
            // Ok, this media file exists on MediaBKP folder, so return it
            //tvStatus.append("\nAchei este arquivo no BKP: " + strResult);
            return strResult;
        }

        // If it goes here, return the original path
        //tvStatus.append("\nNão achei no BKP: " + pStrFilePath);
        return pStrFilePath;

    } // End of fStrCheckMediaClonedFile

    /* =================================================================================

     * ROUTINE     : fStrFindFileInZIP
     * DESCRIPTION : find the Original media file that was inside the ZIP file
     * INPUT       : the File name String
     * OUTPUT      : if it exists in the global HashMap object, return the Path for this filename
     *                if not, return ""
     * OBS         : -
     *
     ================================================================================== */
    private String fStrFindFileInZIP (String pStrFilename) {

        String strReturn;

        // Check whether this file exists in the HashMap
        if (gHMMediaKPFiles.containsKey(pStrFilename)) {
            // It exists, return its path
            strReturn = (String) gHMMediaKPFiles.get(pStrFilename);
        } else {
            strReturn = "";
        }

        return strReturn;

    } // End of fStrFindFileInZIP

    /* =================================================================================

     * ROUTINE     : ListAllMediaClonedFiles
     * DESCRIPTION : populate the global HashMap of Media cloned files
     * INPUT       : the File object, it can be a directory or a file
     * OUTPUT      : -
     * OBS         : -
     *
     ================================================================================== */
    private void ListAllMediaClonedFiles(File pObjDirOrFile) {

        // If it does not exist, do nothing, get out
        if (!pObjDirOrFile.exists())
            return;

        // If it is a File, store it in the global ArrayList
        if (pObjDirOrFile.isFile()) {

            // Add this file in the global HashMap
            gHMMediaKPFiles.put(pObjDirOrFile.getName(),pObjDirOrFile.getPath());

            // and return, because it does not need to dig in this file anymore
            return;

        } // End of IF loop to handle file

        // If it is a Directory, find its children and call this method recursively
        if (pObjDirOrFile.isDirectory()) {

            // List of children folders
            File[] arrObjSubFolders = pObjDirOrFile.listFiles();

            // Loop through all subfolders
            for (int i=0; i<arrObjSubFolders.length; i++) {

                // Call this method in it
                ListAllMediaClonedFiles(arrObjSubFolders[i]);

            } // End of FOR loop for the subfolders

        } // End of IF loop to handle Directory

    } // End of ListAllMediaClonedFiles

    /* =================================================================================

     * ROUTINE     : mWriteTheOriginalUnzippedFile
     * DESCRIPTION : when zipped files, write the original media file
     * INPUT       : the filename of the unzipped media file
     *               the path to the original media file
     * OUTPUT      : -
     * OBS         : -
     *
     ================================================================================== */
    private void mWriteTheOriginalUnzippedFile(String pStrFileName, String pStrPathToOriginalFile) {

        // Fetch the textView for debugging purpose
        TextView tvStatus = (TextView) findViewById(R.id.tvStatus);

        tvStatus.append("\nTENTANDO ESCREVER DESZIPADO " + pStrFileName);

        // Create this specific file in destination
        DocumentFile objDFNewFile = gObjDFPickedDir.createFile("application/octet-stream", pStrFileName);

        InputStream objIS = null;
        OutputStream objOS = null;

        try {
            // Define the output stream (to receive the contents of INPUT file)
            objOS = this.getContentResolver().openOutputStream(objDFNewFile.getUri());

            // Start reading the INPUT file
            objIS = new FileInputStream(pStrPathToOriginalFile);

            // Loop through 1024 bytes chunks in INPUT file
            byte[] buffer = new byte[1024];
            int intRead;
            while ((intRead = objIS.read(buffer)) != -1) {
                // Write these bytes to the destination file (output stream)
                objOS.write(buffer, 0, intRead);
            }

            // Close INPUT stream
            objIS.close();

            // write the output file (now the destination file is ready)
            objOS.flush();
            objOS.close();

        } catch (Exception e) {
            tvStatus.append("\nEXCEPTION mWriteTheOriginalFile: " + e.getMessage());
            return;
        }

    } // End of mWriteTheOriginalFile

    /* =================================================================================

     * ROUTINE     : media_copy_enable_disable
     * DESCRIPTION : enable or disable Media Files copy
     * INPUT       : -
     * OUTPUT      : -
     * OBS         : -
     *
     ================================================================================== */
    private void media_copy_enable_disable() {

        // Fetch the textView for debugging purpose
        TextView tvStatus = (TextView) findViewById(R.id.tvStatus);

        // First check whether it is enabled
        SharedPreferences objSharedPref = this.getPreferences(Context.MODE_PRIVATE);
        String strCopyMediaFilesTxt = getString(R.string.copy_media_files);
        String strCopyMediaFiles = objSharedPref.getString(COPY_MEDIA_FILES,strCopyMediaFilesTxt);

        String strNewMode = "";
        if (strCopyMediaFiles.equals(strCopyMediaFilesTxt)){
            // It is enabled, so disable it
            strNewMode = getString(R.string.do_not_copy_media_files);
        } else {
            // It is disabled, so enable it
            strNewMode = getString(R.string.copy_media_files);
        }

        // Save this mode in Shared Preferences
        SharedPreferences.Editor objEditor = objSharedPref.edit();
        objEditor.putString(COPY_MEDIA_FILES,strNewMode);
        objEditor.commit();

        tvStatus.append("\n" + strNewMode);

    } // End of media_copy_enable_disable

} // End of Main Class
